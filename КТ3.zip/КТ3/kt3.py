import pandas as pd

def get_books(CSV_book):
    df = pd.read_csv(CSV_book, sep='|')
    df['quantity'] = df['quantity'].astype(int)
    df['price'] = df['price'].astype(float)
    return df.values.tolist()

def filtered_books(CSV_book, Python):
    df = pd.DataFrame(CSV_book, columns = ['isbn','title','author','quantity','price'])
    f = df[df['title'].str.contains(Python)]
    df['title, author'] = df['title']+ ',' + df['author']
    return df[['isbn','title, author','quantity','price']].values.tolist()

def Collect(CSV_book):
    df = pd.DataFrame(CSV_book, columns= ['isbn','title, author','quantity','price'])
    df['collect'] = df['quantity'] * df['price']
    return list(zip(df['isbn'], df['collect']))

task1 = get_books("books.csv")
print(task1)

task2 = filtered_books(task1, "Python")
print(task2)

task3 = Collect(task2)
print(task3)